# PageEvidence Strengthening Execution Packet (v9)

## Purpose

Freeze the concrete execution packet for the PageEvidence strengthening lane.

This packet turns the strengthening direction into a bounded executable plan without confusing it with:

- a new candidate-admission lane
- a broad visual subsystem program
- or a general multi-candidate runtime framework

---

## Current milestone position

- M6A workbench already exists
- M6B Candidate A admission already exists
- retained-`baseline` default state is already frozen for the current horizon
- the immediate next bounded move is now a **Lane Class A PageEvidence strengthening lane** focused on substrate quality and projection separation

This means the current lane is justified only if it:

1. improves PageEvidence substrate quality
2. improves Candidate A projection quality
3. preserves retained-default runtime posture
4. avoids broad outward widening

---

## Decided v9 lane posture

This execution packet is frozen to the following decisions:

- **Lane Class A only for the currently authorized implementation scope**
- **Lane Class B later only by separate explicit freeze**
- **Representative fixtures are binding; regression-only drift may occur only with written justification**
- **Medium Lane Class A equivalence posture**:
  - additive internal changes allowed
  - no representative Candidate A projection drift
  - no integrated behavior drift
- **Small fixed set of pre-approved new internal evidence fields in Pass 3 only**
- **No production touch to `nrc_aps_document_processing.py` in Pass 1; analysis-only scratch copy allowed outside `backend` if useful**
- **Strengthened artifacts coexist with the current pinned Candidate A artifact; the old artifact remains historically authoritative unless later explicitly superseded**
- **Passes 1–4 under Lane Class A are authorized**

## Authority note before repo insertion

Until this strengthening pack is inserted into the live repo with verified ordinals and index updates, the live MVVLC control docs on `main` remain the higher authority if any conflict appears.

The companion docs in this pack should therefore be read as **proposed strengthening controls pending repo insertion**. After insertion, the renumbered docs can become part of the active local planning authority.


## Canonical repo authority chain and companion planning docs for this lane

### Live repo authority files

The lane must start from these live repo authority files:

- `backend/app/services/nrc_aps_page_evidence.py`
- `tools/run_nrc_aps_page_evidence_workbench.py`
- `backend/app/services/nrc_aps_document_processing.py`
- `backend/tests/test_nrc_aps_page_evidence.py`
- `tests/test_nrc_aps_page_evidence_workbench.py`
- `tests/reports/mvvlc_candidate_a_page_evidence_workbench_report_v1.json`
- `tests/fixtures/nrc_aps_docs/v1/manifest.json`

### Live repo control docs that bound this lane

The lane must explicitly respect the current merged-main control state recorded in:

- `next_milestone_plans/multi_variant_visual_lane_control/README_INDEX.md`
- `next_milestone_plans/multi_variant_visual_lane_control/00F_LIVE_REPO_VERIFIED_FACTS_AND_OPEN_ITEMS.md`
- `next_milestone_plans/multi_variant_visual_lane_control/03AB_EXACT_M6A_PAGE_EVIDENCE_WORKBENCH_AND_OPTION2_BOUNDARY.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05I_M6A_PAGE_EVIDENCE_WORKBENCH_EXECUTION_PACKET.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05J_M6A_PAGE_EVIDENCE_WORKBENCH_IMPLEMENTATION_RECORD.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05L_M6B_CANDIDATE_A_APPROVED_TARGET_RECORD.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05M_M6B_CANDIDATE_A_ADMISSION_IMPLEMENTATION_RECORD.md`
- `next_milestone_plans/multi_variant_visual_lane_control/03AC_EXACT_POST_ADMISSION_DEFAULTING_SCOPE_AND_DECISION_BOUNDARY.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05O_POST_ADMISSION_DEFAULTING_PLANNING_FREEZE_PACKET.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05P_POST_ADMISSION_RETAIN_BASELINE_DEFAULT_DECISION_RECORD.md`
- `next_milestone_plans/multi_variant_visual_lane_control/05Q_POST_ADMISSION_RETAIN_BASELINE_MERGED_MAIN_CLOSURE_AND_HANDOFF.md`

### Companion docs within this strengthening pack

The following pack-local docs are companion planning controls for this lane. They are not themselves current live repo authority until inserted and ordinalized in the repo:

- `PAGE_EVIDENCE_BLAST_RADIUS_AND_BEFORE_AFTER_TOPOLOGY.md`
- `PAGE_EVIDENCE_FILE_TO_TEST_TO_BUNDLE_TRACEABILITY_MATRIX.md`
- `PAGE_EVIDENCE_SELECTOR_SEMANTICS_AND_BEHAVIOR_DRIFT_POLICY.md`
- `PAGE_EVIDENCE_SCHEMA_AND_ARTIFACT_COMPATIBILITY_POLICY.md`
- `PAGE_EVIDENCE_HIDDEN_CONSUMER_COMPATIBILITY_CHECKLIST.md`

---


## Exact dependency posture

### Default dependency rule

The strengthening lane should remain within the current lightweight dependency posture unless a later stronger freeze explicitly widens it.

Default acceptable dependency posture:

- Python stdlib
- existing `PyMuPDF` / `fitz` usage already present in the repo

Default disallowed new dependency posture:

- `shapely`
- `opencv` / `opencv-python-headless`
- OCR/layout-model libraries for this lane
- any new ML/vision model dependency

Interpretation rule:

- this lane is primarily a **separation / calibration / richer-evidence** lane
- not a new library-adoption lane

If a proposed improvement cannot be achieved without new dependencies, stop and escalate explicitly rather than widening by assumption.

## Exact module / component split target

The lane should target a component split close to the following shape, unless a narrower equivalent is proven simpler:

1. **core evidence extraction**
   - shared page evidence fields
   - deterministic extraction helpers
2. **candidate projection layer**
   - Candidate A-specific projection logic only
3. **runner / reporting layer**
   - workbench/evaluation orchestration
   - artifact writing / stable output handling
4. **tests / evaluation layer**
   - unit tests
   - workbench tests
   - disagreement/evaluation assertions

The lane should not merge these responsibilities more tightly than they are today.

## Exact blast-radius consultation rule

Before editing, the implementation pass must classify the proposed work against:

- change class (R / P / C / H)
- connection surfaces touched
- before-state topology
- allowed after-state topology
- per-file blast radius

using:

- `PAGE_EVIDENCE_BLAST_RADIUS_AND_BEFORE_AFTER_TOPOLOGY.md`
- `PAGE_EVIDENCE_FILE_TO_TEST_TO_BUNDLE_TRACEABILITY_MATRIX.md`
- `PAGE_EVIDENCE_PASS_LEVEL_ALLOWED_FILE_MANIFEST.md`

If the proposed work touches `nrc_aps_document_processing.py`, the lane must explicitly determine whether the change is production-relevant. For v9, the default answer is **do not touch it in Pass 1**, and only treat later production touch as escalation. If an analysis copy is useful, keep it outside `backend`, non-authoritative, and non-runtime.


- strict-equivalence substrate refactor
- or admitted Candidate A behavior drift

before implementation proceeds.



### Interpretation note on taxonomy

Within this packet:

- **Lane classes** govern the overall strengthening lane (`Lane Class A` vs `Lane Class B`)
- **Step classes** govern the blast-radius and control posture of individual implementation steps (`Step Class R / Step Class P / Step Class C / Step Class H`)

If a lane contains more than one step class, the strictest applicable controls govern unless the work is cleanly split into separate passes/commits.



### Required lane-class and equivalence references

Before any pass is approved as Lane Class A, consult:

- `PAGE_EVIDENCE_LANE_A_EQUIVALENCE_AND_NO_DRIFT_GATE.md`
- `PAGE_EVIDENCE_PASS_LEVEL_ALLOWED_FILE_MANIFEST.md`

If the planned pass cannot satisfy those documents, escalate before editing rather than re-labeling the pass optimistically.

## Exact pre-edit stop conditions

The strengthening lane must stop before editing if any of the following is true:

1. the needed implementation would admit a new non-`baseline` selector value
2. the needed implementation would widen outward review/API/report/export schemas or identity surfaces
3. the needed implementation would require a generic candidate registry/framework
4. the needed implementation would reopen OCR / hybrid OCR / media-scope behavior
5. the needed implementation would require review/runtime/report/export visibility redesign
6. the needed implementation cannot preserve current Candidate A admitted behavior without broader program amendment **and** the lane has not been reclassified under the selector-semantics / behavior-drift policy

If a stop condition is encountered, report it explicitly instead of widening by inference.

---

## Exact lane outcome required

The lane must make all of the following true:

1. core PageEvidence produces a shared deterministic evidence record
2. candidate-policy projection is separable from core evidence extraction
3. Candidate A can still derive a projection from the strengthened evidence layer
4. internal evidence richness may increase without outward contract widening
5. current retained-default runtime posture remains unchanged
6. no new runtime-visible selector values are introduced
7. workbench/evaluation artifacts remain deterministic and caller-owned or explicitly pinned
8. no hidden-consumer drift is introduced in retrieval/review/report/export surfaces

If the implementation cannot make all eight true, it is not approve-as-is for this lane.

---

## Exact owner-file boundary

### Primary owner files expected to change

These are the only files that should be assumed editable at the start of the lane:

- `backend/app/services/nrc_aps_page_evidence.py`
- `tools/run_nrc_aps_page_evidence_workbench.py`
- `backend/tests/test_nrc_aps_page_evidence.py`
- `tests/test_nrc_aps_page_evidence_workbench.py`

### Allowed new files by default

Only the following classes of new file should be assumed allowed without broader widening:

- one projection-specific helper under `backend/app/services/` if projection separation cannot remain inside the existing service cleanly
- one evaluation/disagreement helper under `tools/` if the current runner cannot support the frozen evaluation matrix cleanly
- matching narrowly-scoped tests

Any broader new file tree, top-level package, or candidate-framework scaffolding is out of scope by default.

### Conditional owner files

These may become editable only if the primary owner path proves insufficient and the widening is recorded explicitly:

- `backend/app/services/nrc_aps_document_processing.py`
- `tests/test_nrc_aps_document_processing.py`
- a projection-helper import surface if the core service / integrated seam boundary cannot otherwise remain simple and non-fragile

### Inspect-only compatibility / hidden-consumer files

The lane must use the companion inventory and hidden-consumer checklist to justify why these remain inspect-only or why widening becomes necessary.


These must be inspected for compatibility, but should remain edit-free unless a repo-confirmed blocker forces widening:

- `backend/app/services/connectors_nrc_adams.py`
- `backend/app/services/nrc_aps_artifact_ingestion.py`
- `backend/app/services/review_nrc_aps_runtime.py`
- `backend/app/services/nrc_aps_content_index.py`
- retrieval / evidence bundle / review / report/export files touched by `visual_page_refs`

### Exact scope exclusion

The default strengthening lane does **not** authorize:

- new selector admission
- Candidate B/C code surfaces
- runtime visibility redesign
- report/export schema widening
- generic candidate-lifecycle work
- broad subsystem directory creation

---

## Exact lane-class handling rule

The current packet authorizes **Lane Class A only**.

That means:

- the lane may strengthen the substrate
- the lane may separate extraction from projection
- the lane may add only the fixed pre-approved internal fields in Pass 3
- the lane may not materially change admitted Candidate A behavior
- the lane may not silently drift into Lane Class B

If representative-fixture drift or production-relevant seam drift appears, stop and treat that as an escalation point rather than continuing under Lane Class A language.



Before implementation begins, classify the proposed strengthening lane as either:

- **Lane Class A — behavior-preserving substrate strengthening**
- **Lane Class B — behavior-changing Candidate A recalibration**

If the lane is Class B, the selector-semantics / behavior-drift policy becomes mandatory authority and the implementation record must explicitly state why the lane did not require a new selector/version or why such a new selector/version was required.

---

## Exact validation boundary

### Required substrate / projection bundle

- `backend/tests/test_nrc_aps_page_evidence.py`
- `tests/test_nrc_aps_page_evidence_workbench.py`

### Required baseline-compatibility bundle

- `backend/tests/test_nrc_aps_run_config.py`
- `tests/test_nrc_aps_document_processing.py`
- `tests/test_nrc_aps_artifact_ingestion.py`
- `tests/test_nrc_aps_artifact_ingestion_gate.py`

### Required disagreement / evaluation bundle

- a repo-native evaluation/disagreement test or report generation path frozen by the companion evaluation-spec doc

If the lane is classified as behavior-changing, the disagreement/evaluation bundle must compare:

- baseline
- current admitted Candidate A
- proposed strengthened Candidate A

### Performance posture

Performance rerun is required only if the strengthening lane widens into:

- integrated owner-path cost changes
- additional runtime artifact production during normal ingestion
- or heavier extraction logic that materially changes admitted execution cost

If the lane stays fully workbench/local plus seam-local projection-neutral, broader performance reruns are optional.

---


## Exact change-class consultation rule

Before editing begins, every proposed implementation step must be classified against the blast-radius document as one or more of:

- **Class R** — substrate refactor / no material behavior drift
- **Class P** — projection recalibration / admitted Candidate A behavior drift
- **Class C** — schema / artifact compatibility evolution
- **Class H** — hidden-consumer compatibility touch

The lane must also consult:

- `PAGE_EVIDENCE_FILE_TO_TEST_TO_BUNDLE_TRACEABILITY_MATRIX.md`
- `PAGE_EVIDENCE_PASS_SEQUENCING_AND_COMMIT_CHOREOGRAPHY.md`
- `PAGE_EVIDENCE_SELECTOR_SEMANTICS_AND_BEHAVIOR_DRIFT_POLICY.md`

No file should be edited until its change class, traceability path, and required validation bundle are explicitly identified.

## Exact behavior-drift rule

A proposed change may be treated as behavior-preserving only if it meets the behavior-preserving criteria frozen by the selector-semantics policy.

If representative fixtures or accepted admitted-behavior anchors change materially, the lane must escalate to behavior-changing handling even if the code diff looks small.

## Allowed new files by default

The lane may add a narrow number of new files only if they remain inside the frozen strengthening boundary. Default-allowed new file classes are:

- one shared projection-helper module
- one evaluation/disagreement helper module or report builder
- additive tests supporting the frozen validation matrix

Disallowed by default:

- generic candidate registry files
- new outward API/review/report schema files
- broad subsystem directory trees

## Exact widening rules

Allowed widening trigger classes are only:

1. projection separation cannot be achieved cleanly without a narrow shared seam adjustment
2. disagreement/evaluation validation cannot be made durable without a narrow runner/report compatibility change
3. an inspect-only hidden-consumer file proves to be the real canonical normalization / compatibility surface

Every widening decision must be recorded explicitly in the final report as:

- file widened into
- reason class
- why the default owner set was insufficient
- what new risk the widening introduced

---

## Exact no-drift assertions the lane must prove

The lane must prove all of the following:

- retained-`baseline` runtime posture remains unchanged
- Candidate A remains the only admitted non-`baseline` value
- no new outward review/API/report/export identity fields were introduced
- no hidden-consumer drift was introduced in retrieval/evidence/review/report/export surfaces
- no broader candidate framework was introduced by implication
- workbench/evaluation artifacts remain deterministic and bounded

---

## Exact status language allowed at the end of the lane

The lane may be described as approve-as-is only if it provides:

1. a shared deterministic PageEvidence layer
2. separable Candidate A projection logic
3. stronger evaluation/disagreement evidence
4. explicit no-drift findings on retained-default runtime posture and hidden-consumer compatibility

Do not use broader overclaim language such as:

- subsystem complete
- multi-candidate foundation complete
- future-ready visual layer complete

unless a later explicit broader program freeze actually exists.

---

## Immediate next action after this packet

The next justified move is:

1. work in a fresh strengthening lane/worktree
2. implement separation of evidence extraction from projection logic
3. improve Candidate A projection quality and internal evidence richness only within the packet frozen here
4. validate through substrate/projection/disagreement bundles
5. freeze the lane separately in a final implementation record
6. only then decide whether any later broader PageEvidence or candidate-neutral substrate work is justified
