# PageEvidence Pack Insertion and Ordinalization Plan

## Purpose

Freeze the repo-insertion plan for the PageEvidence strengthening pack so the pack can be translated into the live MVVLC sequence with minimal ambiguity.

This document is operational. It does not widen the substantive scope of the strengthening lane.

---

## Current live-pack anchor state

At pack-creation time, the live MVVLC pack on `main` records:

- `03AC` as the current highest `03*` control doc used in the active spine
- `05Q` as the current highest `05*` control doc used in the active spine

A live repo search was used during pack preparation to verify that the following candidate ordinals were not already present in the MVVLC directory at that time:

- `03AD`
- `03AE`
- `03AF`
- `05R`
- `05S`
- `05T`

This verification reduces collision risk but does not eliminate the need for a final pre-insertion check immediately before merge.

---

## Insertion rule

Before insertion:

1. re-check the current MVVLC directory for ordinal collisions
2. re-check `README_INDEX.md` for any parallel updates that alter the correct insertion point
3. confirm whether the strengthening pack is being inserted as:
   - a post-M6 refinement lane inside MVVLC
   - or a parallel refinement/control sub-pack that still lives in the MVVLC directory

Do not assign ordinals from memory.

---

## Provisional ordinal mapping if no concurrent changes exist

These mappings are **provisional only**. They become usable only if a fresh pre-insertion collision check remains clean.

### `03*` range

Use the next three free `03*` slots for strengthening-boundary/control docs:

- `03AD_EXACT_PAGE_EVIDENCE_SHARED_EVIDENCE_AND_PROJECTION_SEPARATION_BOUNDARY.md`
- `03AE_PAGE_EVIDENCE_SELECTOR_SEMANTICS_AND_BEHAVIOR_DRIFT_POLICY.md`
- `03AF_PAGE_EVIDENCE_LANE_A_EQUIVALENCE_AND_NO_DRIFT_GATE.md`

Rationale:
- these three docs define the actual control boundary for the lane
- they are closer to the repo's existing `03*` “exact policy/boundary/mechanism” family than to execution-packet or implementation-record families

### `05*` range

Use the next three free `05*` slots for execution/roadmap/record docs:

- `05R_PAGE_EVIDENCE_STRENGTHENING_EXECUTION_PACKET.md`
- `05S_PAGE_EVIDENCE_STRENGTHENING_ROADMAP_AND_DECISION_NOTES.md`
- `05T_PAGE_EVIDENCE_STRENGTHENING_IMPLEMENTATION_RECORD.md`

Rationale:
- `05*` already functions as the main packet / implementation-record band in the live MVVLC pack
- the roadmap is sufficiently operational that it fits better alongside the execution packet than as a loose companion note

### Companion operational docs

The remaining docs should remain companion planning/control docs unless the live repo decides to promote them into the ordinalized spine.

Default recommendation:
- keep companion docs role-labelled until the repo determines they need full ordinalized status
- if promoted, group them after the primary boundary/packet docs rather than interleaving them arbitrarily

---

## Minimum insertion set

The smallest repo insertion set that still preserves the value of this pack is:

1. boundary / separation doc
2. execution packet
3. selector semantics / behavior-drift policy
4. Lane Class A equivalence / no-drift gate
5. roadmap / decision notes
6. implementation record template or later live implementation record

The companion docs should still travel with the pack, but they do not all need immediate ordinalized promotion if the repo wants to minimize spine expansion.

---

## Recommended insertion order

1. insert the boundary doc
2. insert the selector-semantics / behavior-drift policy
3. insert the Lane Class A equivalence gate
4. insert the execution packet
5. insert the roadmap / decision-notes doc
6. insert the implementation-record template or create the final implementation record later
7. update `README_INDEX.md` and any navigation docs
8. only then start implementation from a clean worktree

---

## README/index update rule

At insertion time, update:

- `next_milestone_plans/multi_variant_visual_lane_control/README_INDEX.md`

The update should explicitly state:

- that the strengthening pack is a post-M6 refinement lane
- that it does not alter the retained-`baseline` current-horizon default by implication
- that Candidate A remains the only admitted non-`baseline` selector value unless a later explicit amendment says otherwise
- that the current pack is Lane Class A only for now, with Lane Class B remaining future scope only by separate freeze

---

## Final pre-merge checklist

Before merge, confirm all of the following:

- ordinal filenames are collision-free
- README/index references are updated
- companion docs reference the final inserted filenames where needed
- no pack-local doc claims higher authority than the live repo state before insertion
- no inserted doc implicitly opens Candidate B or broader MVVLC scope
- the provisional mapping still matches the live ordinal surface immediately before merge

---

## Result

This plan makes repo insertion explicit, repeatable, and low-fragility instead of leaving it to ad hoc filename assignment at merge time.
