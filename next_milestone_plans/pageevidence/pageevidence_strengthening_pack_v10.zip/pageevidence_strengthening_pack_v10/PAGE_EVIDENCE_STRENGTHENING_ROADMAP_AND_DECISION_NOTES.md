# PageEvidence Strengthening Roadmap and Decision Notes

## Purpose

Provide one consolidated roadmap for the PageEvidence strengthening effort so the next moves, pass order, decision gates, escalation triggers, and post-pass branching do not need to be reconstructed across multiple docs.

This roadmap is subordinate to the execution packet and selector-semantics policy.
It does not widen scope beyond what those docs allow.

---

## Decided v9 roadmap posture

This roadmap is frozen to the following decisions:

1. **Lane Class A only for the currently authorized implementation scope**
2. **Lane Class B is later scope only by separate explicit freeze**
3. **Representative fixtures are binding for Lane Class A equivalence**
4. **Regression-only drift may occur only with written justification**
5. **A threshold/percentage-based materiality rule is possible later, but not part of the current lane**
6. **Passes 1–4 under Lane Class A are authorized**
7. **The first lane should avoid touching `nrc_aps_document_processing.py`; analysis against a non-authoritative scratch copy is acceptable if useful, but production-file edits remain escalation-only**
8. **Strengthened artifacts coexist with the current pinned Candidate A artifact; the old artifact remains historically authoritative unless later explicitly superseded**

---

## Decision gate 0 — Choose the lane class before code starts

Exactly one of the following lane classes must be chosen before implementation:

### Lane Class A — substrate strengthening / no material Candidate A behavior drift

Meaning:

- improve PageEvidence as shared deterministic evidence infrastructure
- preserve current admitted Candidate A behavior materially
- do not change selector meaning in practice

Current recommendation and v9 decision:

- **Chosen and authorized now**

### Lane Class B — Candidate A recalibration / material admitted behavior drift allowed

Meaning:

- alter what the admitted Candidate A path actually does materially
- potentially require selector-semantics amendment or new-version handling

Current recommendation and v9 decision:

- **Not authorized now**
- only later scope by separate explicit freeze

If uncertainty exists, default to **Lane Class A**.

---

## Decision gate 1 — Repo insertion first

The strengthening pack should become repo-native before code work starts if practical.

Required actions:

1. run the repo insertion / ordinalization plan
2. update the pack index / navigation surface
3. make authority ordering explicit

If this has not been done, implementation should stop unless an explicit exception is granted.

---

## Roadmap phases

### Phase 1 — repo insertion and authority alignment

Goals:
- map the pack docs to verified live ordinals
- update the relevant pack index / navigation surface
- ensure the strengthening pack is explicitly positioned relative to current MVVLC control docs
- freeze that the lane is a **post-M6 refinement lane under Lane Class A only**

Exit condition:
- the pack is repo-native and authority ordering is explicit

### Phase 2 — live repo reconnaissance / source-of-truth confirmation

Goals:
- re-read the actual live source files before editing
- confirm the current PageEvidence service / runner / Candidate A seam-local consumer shape
- confirm hidden-consumer surfaces have not drifted materially since the planning pack was drafted
- confirm the pinned workbench artifact is still the canonical before-state reference

Exit condition:
- source-of-truth assumptions still hold, or new drift is explicitly recorded before implementation begins

### Phase 3 — Lane Class A substrate strengthening

Default subpasses:

#### Pass 1
- cleanup and lifecycle hardening
- explicit `fitz` close / cleanup semantics
- no artifact meaning change
- no admitted behavior drift
- no production touch to `nrc_aps_document_processing.py`

#### Pass 2
- shared evidence / candidate projection separation
- compatibility bridge if required
- preserve current admitted Candidate A behavior
- no production touch to `nrc_aps_document_processing.py` unless a separate escalation is approved

#### Pass 3
- additive internal evidence-field enrichment
- only fields frozen in the field-definition register:
  - `largest_image_bbox_ratio`
  - `largest_drawing_bbox_ratio`
  - `dominant_visual_region_present`
  - `text_visual_overlap_ratio`
  - `meaningful_visual_region_count` (optional)
- no consumption by admitted Candidate A path unless separately justified

#### Pass 4
- evaluation / disagreement expansion
- stronger summaries
- borderline-page visibility
- baseline vs current admitted Candidate A checks

Exit condition:
- shared deterministic evidence extractor exists
- projection is separable
- retained-default posture unchanged
- no hidden-consumer drift
- no representative-fixture material drift
- any regression-only drift is explicitly justified

### Phase 4 — optional Lane Class B recalibration

Not authorized under the current v9 lane.

This phase may be opened only by a separate future freeze.

---

## Decision gates between phases/passes

### Gate A — after repo insertion
Question:
- Is the pack now repo-native, correctly ordered, and authority-clear?

If no:
- stop before implementation

### Gate B — after reconnaissance
Question:
- Does the live repo still match the assumptions the pack was built on?

If no:
- update the pack or stop

### Gate C — before Pass 2
Question:
- Can evidence/projection separation be done without touching the admitted Candidate A behavior?

If yes:
- remain Lane Class A
If no:
- stop and prepare a future separate freeze rather than silently drifting toward Lane Class B

### Gate D — before Pass 3
Question:
- Are the new internal evidence fields fully defined and compatibility-safe?

If no:
- stop until the field-definition register is tightened

### Gate E — before Pass 4
Question:
- Is the disagreement/evaluation output sufficient to detect borderline and representative-fixture drift?

If no:
- strengthen evaluation before proceeding

---

## Post-pass branching options

After a successful Lane Class A pass, only the following next moves are justified:

1. **Stop and hold**
   - strengthened substrate in place
   - no further PageEvidence action for current horizon

2. **Open a bounded future Lane Class B recalibration**
   - only by separate explicit freeze

3. **Open a later candidate-neutral comparison planning lane**
   - only if separately frozen
   - not implied by substrate strengthening alone

4. **Open a broader program-amendment lane**
   - only if the project truly intends to move beyond current retained-default MVVLC posture

---

## Escalation triggers

The following automatically require escalation review:

1. touching `backend/app/services/nrc_aps_document_processing.py` in a production-relevant way
2. changing the meaning of the currently admitted selector value
3. changing workbench artifact meaning without explicit schema/artifact compatibility handling
4. requiring hidden-consumer file changes outside the default owner set
5. introducing new dependencies beyond the frozen dependency posture for this lane
6. changing representative-fixture outcomes in a way that is not explicitly classified as acceptable drift

---

## Validation order

### Lane Class A minimum order
1. service/projection tests
2. runner/report tests
3. baseline-compatibility bundle
4. hidden-consumer compatibility checklist
5. artifact compatibility checks
6. disagreement/evaluation outputs

Lane Class B validation is out of current scope.

---

## Rollback checkpoints

Recommended rollback anchors:

1. post-insertion, pre-code
2. post-cleanup, pre-separation
3. post-separation, pre-field-enrichment
4. post-field-enrichment, pre-evaluation expansion

---

## Result

This roadmap now gives the lane a single explicit execution narrative: repo insertion first, Lane Class A only, Passes 1–4 only, representative-fixture equivalence binding, regression-only drift by written justification only, and Lane Class B deferred until separately frozen.
